﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TTEC
{
    public partial class MainWindow : Window
    {
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Calculator w2 = new Calculator();
            w2.Owner = this;
            w2.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SBOL w2 = new SBOL();
            w2.Owner = this;
            w2.Show();
        }
    }
    class MyButton : Button
    {
        public Type UserWindowTyps { get; set; }

        protected override void OnClick()
        {
            base.OnClick();
            Window win = Activator.CreateInstance(this.UserWindowTyps) as Window;
            if (win != null)
            {
                win.ShowDialog();
            }
        }
    }
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
        }
    }
}
