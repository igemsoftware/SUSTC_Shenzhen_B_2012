﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Web;
using System.Web.Services;

namespace TTEC
{
    /// <summary>
    /// Calculator.xaml 的交互逻辑
    /// </summary>
    public partial class Calculator : Window
    {
        public Calculator()
        {
            InitializeComponent();
            Algorithm2.setStackData();
            Algorithm2.setTStackIData();
            Algorithm2.setTStackHData();
            Algorithm2.setLoopSizeData();
            Algorithm2.setTriloopData();
            Algorithm2.setTetraloopData();
            Algorithm2.setInterior_1x2_Data();
            Algorithm2.setInterior2x2Data();


        
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            textBox1.Text = "AAAAAAACCCCGCGGTTTTCCGCGGGGTTTTTTTTTTTTTTTTTTT";
        }

        //new added: needn't to change
        private string seqs = "";
        private string matches = "";
        private int color1 = 0xff0000;
        private int color2 = 0x00ff00;
        //
        public int getColor1() { return color1; }
        public int getColor2() { return color2; }
        public string getSeqs() { return seqs; }
        public string getMatches() { return matches; }
        //
        private void setColor1(int c) { color1 = c; }
        private void setColor2(int c) { color2 = c; }
        private void setSeqs(string s) { seqs = s; }
        private void setMatches(string s) { matches = s; }
        //
        private RNAViewer rnaViwer = new RNAViewer();
        private RNAViewer.Args rnaViwerArgs = new RNAViewer.Args();
        private const string rnaDir = "rnaImages";
        private const string errorlImg = "./" + rnaDir + "/default/error.gif";
        private const string defautlImg = "./" + rnaDir + "/default/default.gif";
        private string rnaImageName = defautlImg;
        public string getRNAImageName() { return rnaImageName; }
        private void setRNAImageName(string s) { rnaImageName = s; }
        //

        private bool createRNAImage(int numFileLimit = 50)
        {
            string rootDir = "C:\\";
            rootDir = rootDir.Substring(0, rootDir.Length - 1);
            string imageName = seqs + ".gif";
            string path = rootDir + "\\" + rnaDir;
            //Create it if not exist.
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            string[] files = Directory.GetFiles(rootDir + "\\" + rnaDir);
            //Delete files when the number of file exceeds numFileLimit.
            if (files.Length > numFileLimit) for (int i = 0; i < files.Length; i++) File.Delete(files[i]);

            if (!File.Exists(path + "\\" + imageName))
            {
                //if haven't created it before,init rnaViwer and use rnaViwer to create one.
                if (!rnaViwer.init(seqs, matches))
                {
                    //if arg error,set the img to !!errorlImg!! sued by client.
                    setRNAImageName(errorlImg);
                    return false;
                }
                //now,create the file...
                rnaViwer.create(path + "\\" + imageName, rnaViwerArgs);
            }
            //set the fileName used by client.
            setRNAImageName("./" + rnaDir + "/" + imageName);
            return true;
        }
        





        

        protected void button1_Click(object sender, EventArgs e)
        {
            string str="";

            string sequence="";
            int i, j;
            j = 0;
            sequence = textBox1.Text;
            label7.Content = "";
            if (sequence.Length <= 14)
            {
                label5.Content = "Please input correct sequence!";
                label3.Content = "00%";
            }
            else
            {
                for (i = 0; i < sequence.Length; i++)

                    if (sequence.Substring(i, 1) != " " & sequence.Substring(i, 1) != "u" & sequence.Substring(i, 1) != "c" & sequence.Substring(i, 1) != "g" & sequence.Substring(i, 1) != "t" & sequence.Substring(i, 1) != "a" & sequence.Substring(i, 1) != "U" & sequence.Substring(i, 1) != "C" & sequence.Substring(i, 1) != "G" & sequence.Substring(i, 1) != "T" & sequence.Substring(i, 1) != "A")
                    {
                        label5.Content = "Please input correct sequence!";
                        label3.Content = "00%"; j = 1; break;
                    }
                if (j == 0)
                {
                    sequence.ToUpper();
                    sequence.Trim();
                    if (radioButton1.IsChecked == true) IO.Algorithm_Two(sequence, true,false,"");
                    else
                    {                       
                        IO.Algorithm_Two(sequence, false,false,"");
                        sequence = OverallManager.getForwardTerminatorSequence(sequence, false);
                    }

                        if (Algorithm1.Warn == false)
                        {

                            setSeqs(sequence); setMatches(IO.structure); createRNAImage(50);


                            label3.Content = IO.efficiency + "%";

                            label5.Content = "";
                            BitmapImage bitmapImage;
                            bitmapImage = new BitmapImage();

                            bitmapImage.BeginInit();
                            str = @"c:\rnaImages" + "\\" + seqs + ".gif";
                            bitmapImage.StreamSource = System.IO.File.OpenRead(str);

                            bitmapImage.EndInit();

                            image1.Source = bitmapImage;
                            label7.Content = "The Image of your Sequence is saved in  'C:\\rnaImages\'.";
                        }
                        else
                        {
                            label5.Content = errorDisplay.Warning;
                            label3.Content = "00%";
                            BitmapImage bitmapImage;
                            bitmapImage = new BitmapImage();

                            bitmapImage.BeginInit();
                            str = @"img05614.jpg";
                            bitmapImage.UriSource = new Uri(@"img05614.jpg", UriKind.Relative);

                            bitmapImage.EndInit();

                            image1.Source = bitmapImage;
                        }
                    }


                }
            }
        

        private void textBox1_TextChanged(object sender, TextChangedEventArgs e)
        {
            string sequence;
            int i, j;
            j = 0;
            sequence = textBox1.Text;
            for (i = 0; i < sequence.Length; i++)

                if (sequence.Substring(i, 1) != "u" & sequence.Substring(i, 1) != "c" & sequence.Substring(i, 1) != "g" & sequence.Substring(i, 1) != "t" & sequence.Substring(i, 1) != "a" & sequence.Substring(i, 1) != "U" & sequence.Substring(i, 1) != "C" & sequence.Substring(i, 1) != "G" & sequence.Substring(i, 1) != "T" & sequence.Substring(i, 1) != "A")
                {
                    label5.Content = "Please input correct sequence!";
                    label3.Content = "00%";
                    j = 1; break;
                    
                }
                else
                {
                    label5.Content = "";
                }
        }

    }
}
