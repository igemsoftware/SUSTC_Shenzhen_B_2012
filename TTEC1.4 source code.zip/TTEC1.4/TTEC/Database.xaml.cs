﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TTEC
{
    /// <summary>
    /// Interaction logic for Database.xaml
    /// </summary>
    public partial class Database : Window
    {
        public class Terminator1
        {
            public string Terminator_Name { get; set; }
            public string Category { get; set; }
            public string Direction { get; set; }
            public string Environment { get; set; }
            public string Stem_Loop_Sequence { get; set; }
            public string Loop { get; set; }
            public string Tail { get; set; }
            public string Forward_Efficiency { get; set; }
            public string Reverse_Efficiency { get; set; }
            public string Full_sequnce { get; set; }
            public string Reference { get; set; }
            public string Note { get; set; }
            public string spacer { get;set; }

        }

        public Database()
        {
            InitializeComponent();

            List<Terminator1> terList = new List<Terminator1>()
            {
                
                new Terminator1(){Terminator_Name="BBa_B0011",Category="artificial(Designed by Reshma Shetty)",Direction="Bidirectional",Environment="E. coli",Stem_Loop_Sequence="GCCAGATTATTAATCCGGC",Loop="ATT",spacer=" ",Tail="TTTTTTATTATTT",Forward_Efficiency="41.9%[CC]/95%[JK]",Reverse_Efficiency="63.6%[CC]/86%[JK]",Full_sequnce="AGAGAATATAAAAAGCCAGATTATTAATCCGGCTTTTTTATTATTT",Reference="http://partsregistry.org/Terminators/Catalog#Reverse_terminators",Note=""},

                
                

                new Terminator1(){Terminator_Name="BBa_B0014",Category="artificial(Designed by Reshma Shetty)",Direction="Bidirectional",Environment="E. coli",Stem_Loop_Sequence=" ",Loop=" ",spacer=" ",Tail=" ",Forward_Efficiency="60.4%[CC]/96%[JK]",Reverse_Efficiency="86%[JK]",Full_sequnce="TCACACTGGCTCACCTTCGGTGGGCCTTTCTGCGTTTATATACTAGAGAGAGAATATAAAAAGCCAGATTATTAATCCGGCTTTTTTATTATTT",Reference="http://partsregistry.org/Terminators/Catalog#Reverse_terminators",Note="double terminator combined of BBa_B0012 and BBa_B0011"},

                new Terminator1(){Terminator_Name="BBa_B0015",Category="artificial(Designed by Reshma Shetty)",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence=" ",Loop=" ",spacer=" ",Tail=" ",Forward_Efficiency="98.4%[CC]/97%[JK]",Reverse_Efficiency="0.295[CC]/0.62[JK]",Full_sequnce="CCAGGCATCAAATAAAACGAAAGGCTCAGTCGAAAGACTGGGCCTTTCGTTTTATCTGTTGTTTGTCGGTGAACGCTCTCTACTAGAGTCACACTGGCTCTCACACTGGCTCACCTTCGGGTGGGCCTTTCTGCGTTTATA",Reference="http://partsregistry.org/Terminators/Catalog#Reverse_terminators",Note="double terminator combined of BBa_B0012 and BBa_B0010"},

                
                
                new Terminator1(){Terminator_Name="BBa_B0021",Category="artificial(Designed by Caitlin Conboy)",Direction="Bidirectional",Environment="E. coli",Stem_Loop_Sequence="GCCAGATTATTAATCCGGC",Loop="ATT",spacer=" ",Tail="TTTTTTATTATTT",Forward_Efficiency="63.6%[CC]/86%[JK]",Reverse_Efficiency="41.9%[CC]/95%[JK]",Full_sequnce="AGAGAATATAAAAAGCCAGATTATTAATCCGGCTTTTTTATTATTT",Reference="http://partsregistry.org/Terminators/Catalog#Reverse_terminators",Note="reverse of BBa_B0011"},

                
                
                new Terminator1(){Terminator_Name="BBa_B0024",Category="artificial(Designed by Caitlin Conboy)",Direction="Bidirectional",Environment="E. coli",Stem_Loop_Sequence="GGCTCACCTTGGGTGGGCC",Loop="TTG",spacer=" ",Tail="TTTCTGCGTTTATATACTAGAGAGAGAATATAAAAAGCCAGATTATTAATCCGGCTTTTTTATTATTT",Forward_Efficiency="86%[JK]",Reverse_Efficiency="60.4%[CC]/96%[JK]",Full_sequnce="TCACACTGGCTCACCTTCGGTGGGCCTTTCTGCGTTTATATACTAGAGAGAGAATATAAAAAGCCAGATTATTAATCCGGCTTTTTTATTATTT",Reference="http://partsregistry.org/Terminators/Catalog#Reverse_terminators",Note="reverse of BBa_B0014"},

                new Terminator1(){Terminator_Name="BBa_B0025",Category="artificial(Designed by Caitlin Conboy)",Direction="Reverse",Environment="E. coli",Stem_Loop_Sequence="ATAAAACGAAAGGCTCAGTCGAAAGACTGGGCCTTTCGTTTTAT",Loop="GAAA",spacer="C",Tail="TGTTGTTTGTCGGTGAACGCTCTCTACTAGAGTCACACTGGCTCACCTTCGGGTGGGCCTTTCTGCGTTTATA",Forward_Efficiency="29.5%[CC]/62%[JK]",Reverse_Efficiency="98.4%[CC]/97%[JK]",Full_sequnce="CCAGGCATCAAATAAAACGAAAGGCTCAGTCGAAAGACTGGGCCTTTCGTTTTATCTGTTGTTTGTCGGTGAACGCTCTCTACTAGAGTCACACTGGCTCACCTTCGGGTGGGCCTTTCTGCGTTTATA",Reference="http://partsregistry.org/Terminators/Catalog#Reverse_terminators",Note="reverse of BBa_B0015"},
                
                new Terminator1(){Terminator_Name="BBa_B1001",Category="artificial(Designed by Haiyao Huang)",Direction="Bidirectional",Environment="E. coli",Stem_Loop_Sequence="CCCCGCTTCGGCGGGG",Loop="TTCG",spacer=" ",Tail="TTTTTTTTT",Forward_Efficiency="81%[CH]",Reverse_Efficiency="",Full_sequnce="AAAAAAAAACCCCGCTTCGGCGGGGTTTTTTTTT",Reference="Design and Characterization of Artificial Transcriptional Terminators by Haiyao Huang",Note=""},
  
                new Terminator1(){Terminator_Name="BBa_B1002",Category="artificial(Designed by Haiyao Huang)",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCCGCTTCGGCGGGG",Loop="TTCG",spacer=" ",Tail="TTTTTT",Forward_Efficiency="98%[CH]",Reverse_Efficiency="",Full_sequnce="AAAAAACCCCGCTTCGGCGGGGTTTTTT",Reference="Design and Characterization of Artificial Transcriptional Terminators by Haiyao Huang",Note=""},

                new Terminator1(){Terminator_Name="BBa_B1003",Category="artificial(Designed by Haiyao Huang)",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCCGCTTCGGCGGGG",Loop="TTCG",spacer=" ",Tail="TTTTT",Forward_Efficiency="83%[CH]",Reverse_Efficiency="",Full_sequnce="AAAAACCCCGCTTCGGCGGGGTTTTT",Reference="Design and Characterization of Artificial Transcriptional Terminators by Haiyao Huang",Note=""},

                new Terminator1(){Terminator_Name="BBa_B1004",Category="artificial(Designed by Haiyao Huang)",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCCGCTTCGGCGGGG",Loop="TTCG",spacer=" ",Tail="TTTT",Forward_Efficiency="93%[CH]",Reverse_Efficiency="",Full_sequnce="AAAACCCCGCTTCGGCGGGGTTTT",Reference="Design and Characterization of Artificial Transcriptional Terminators by Haiyao Huang",Note=""},

                new Terminator1(){Terminator_Name="BBa_B1005",Category="artificial(Designed by Haiyao Huang)",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCCGCTTCGGCGGGG",Loop="TTCG",spacer=" ",Tail="TTT",Forward_Efficiency="86%[CH]",Reverse_Efficiency="",Full_sequnce="AAACCCCGCTTCGGCGGGGTTT",Reference="Design and Characterization of Artificial Transcriptional Terminators by Haiyao Huang",Note=""},
 
                new Terminator1(){Terminator_Name="BBa_B1006",Category="artificial(Designed by Haiyao Huang)",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCCGCCCCTGACAGGGCGGGG",Loop="CAGTCA",spacer=" ",Tail="TTTTTTTTT",Forward_Efficiency="99%[CH]",Reverse_Efficiency="",Full_sequnce="AAAAAAAAACCCCGCCCCTGACAGGGCGGGGTTTTTTTTT",Reference="Design and Characterization of Artificial Transcriptional Terminators by Haiyao Huang",Note=""},

                new Terminator1(){Terminator_Name="BBa_B1007",Category="artificial(Designed by Haiyao Huang)",Direction="Bidirectional",Environment="E. coli",Stem_Loop_Sequence="CCCCGCCCCTGACAGGGCGGGG",Loop="CAGTCA",spacer=" ",Tail="TTTTTT",Forward_Efficiency="83%[CH]",Reverse_Efficiency="",Full_sequnce="AAAAAACCCCGCCCCTGACAGGGCGGGGTTTTTT",Reference="Design and Characterization of Artificial Transcriptional Terminators by Haiyao Huang",Note=""},

                new Terminator1(){Terminator_Name="BBa_B1008",Category="artificial(Designed by Haiyao Huang)",Direction="Bidirectional",Environment="E. coli",Stem_Loop_Sequence="CCCCGCCCCTGACAGGGCGGGG",Loop="CAGTCA",spacer=" ",Tail="TTTTT",Forward_Efficiency="95%[CH]",Reverse_Efficiency="",Full_sequnce="AAAAACCCCGCCCCTGACAGGGCGGGGTTTTT",Reference="Design and Characterization of Artificial Transcriptional Terminators by Haiyao Huang",Note=""},

                new Terminator1(){Terminator_Name="BBa_B1009",Category="artificial(Designed by Haiyao Huang)",Direction="Bidirectional",Environment="E. coli",Stem_Loop_Sequence="CCCCGCCCCTGACAGGGCGGGG",Loop="CAGTCA",Tail="TTTT",Forward_Efficiency="94%[CH]",Reverse_Efficiency="",Full_sequnce="AAAACCCCGCCCCTGACAGGGCGGGGTTTT",Reference="Design and Characterization of Artificial Transcriptional Terminators by Haiyao Huang",Note=""},

                new Terminator1(){Terminator_Name="BBa_B10010",Category="artificial(Designed by Haiyao Huang)",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCCGCCCCTGACAGGGCGGGG",Loop="CAGTCA",spacer=" ",Tail="TTT",Forward_Efficiency="95%[CH]",Reverse_Efficiency="",Full_sequnce="AAACCCCGCCCCTGACAGGGCGGGGTTT",Reference="Design and Characterization of Artificial Transcriptional Terminators by Haiyao Huang",Note=""},

                new Terminator1(){Terminator_Name="trpC302",Category="mutant",Direction="Forward",Environment="mutant",Stem_Loop_Sequence="CTGGCCGGATCCGGCCAG",Loop="GATC",spacer=" ",Tail="TTTT",Forward_Efficiency="8%",Reverse_Efficiency="",Full_sequnce="CTGGCCGGATCCGGCCAGTTTT",Reference="Christie, G., Farnham, P. J. &Platt, T. (1981). Proc. Nat. Acad. Sci., U.S.A. 78, 4180-4183.",Note=""},

                new Terminator1(){Terminator_Name="trp t",Category="mutant",Direction="Forward",Environment="mutant",Stem_Loop_Sequence="GCCGCCAGTTCCGCTGGCGGC",Loop="TTCCG",spacer=" ",Tail="TTTT",Forward_Efficiency="25%",Reverse_Efficiency="",Full_sequnce="GCCGCCAGTTCCGCTGGCGGCTTTT",Reference="Christie, G., Farnham, P. J. &Platt, T. (1981). Proc. Nat. Acad. Sci., U.S.A. 78, 4180-4184.",Note=""},

                new Terminator1(){Terminator_Name="trp a1419",Category="wild type",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="AGCCCGCCTAATGAGCGGGCT",Loop="CTAATGA",spacer=" ",Tail="TTTGCAAGGTT",Forward_Efficiency="3%",Reverse_Efficiency="",Full_sequnce="CCAGCCCGCCTAATGAGCGGGCTTTTGCAAGGTT",Reference="Christie, G., Farnham, P. J. &Platt, T. (1981). Proc. Nat. Acad. Sci., U.S.A. 78, 4180-4185.",Note=""},

                new Terminator1(){Terminator_Name="trp a",Category="wild type",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="AGCCCGCCTAAGAGCGGGCTGT",Loop="CTAAGA",spacer=" ",Tail="TTTTTTT",Forward_Efficiency="98%",Reverse_Efficiency="",Full_sequnce="AGCCCGCCTAAGAGCGGGCTGTTTTTTTT",Reference="Christie, G., Farnham, P. J. &Platt, T. (1981). Proc. Nat. Acad. Sci., U.S.A. 78, 4180-4186.",Note=""},

                new Terminator1(){Terminator_Name="trp a135",Category="mutant",Direction="Forward",Environment="mutant",Stem_Loop_Sequence="CAGCCCGCCTAAGAGCGGGCTG",Loop="CTAAGA",spacer=" ",Tail="TTTTTT",Forward_Efficiency="65%",Reverse_Efficiency="",Full_sequnce="CAGCCCGCCTAAGAGCGGGCTGTTTTTT",Reference="Christie, G., Farnham, P. J. &Platt, T. (1981). Proc. Nat. Acad. Sci., U.S.A. 78, 4180-4186.",Note=""},

                new Terminator1(){Terminator_Name="rrnB t1",Category="wild type",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCTCAGTCGAAAGACTGGGCC",Loop="GAAA",spacer=" ",Tail="TTTCGTTTTAAT",Forward_Efficiency="84+1%",Reverse_Efficiency="",Full_sequnce="GGCTCAGTCGAAAGACTGGGCCTTTCGTTTTAAT",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="tonB t",Category="wild type",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="AGCCTCCGACCGGAGGCT",Loop="AC",spacer=" ",Tail="TTTGACTATTA",Forward_Efficiency="19+1%",Reverse_Efficiency="",Full_sequnce="TCAAAAGCCTCCGACCGGAGGCTTTTGACTATTA",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="trp a",Category="wild type",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="AGCCCGCCTAATGAGCGGGCT",Loop="CTAATGA",spacer=" ",Tail="TTTTTTTGAAC",Forward_Efficiency="71+2%",Reverse_Efficiency="",Full_sequnce="CCAGCCCGCCTAATGAGCGGGCTTTTTTTTGAAC",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="trp a L126",Category="mutant",Direction="Forward",Environment="mutant",Stem_Loop_Sequence="GCCCGCCTAATAAGCGGGC",Loop="CTAATAA",spacer=" ",Tail="TTTTTTTTGAAC",Forward_Efficiency="65+4%",Reverse_Efficiency="",Full_sequnce="CCAGCCCGCCTAATAAGCGGGCTTTTTTTTGAAC",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="trp a L153",Category="mutant",Direction="Forward",Environment="mutant",Stem_Loop_Sequence="CCGCCTAATAAGCGG",Loop="CTAATAA",spacer=" ",Tail="TTTTTTTTGAAC",Forward_Efficiency="8+4%",Reverse_Efficiency="",Full_sequnce="CCAGCCCGCCTAATAAGCGGACTTTTTTTTGAAC",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="T7Te",Category="wild type",Direction="Forward",Environment="phage terminator",Stem_Loop_Sequence="GGCTCACCTTCGGGTGGGCC",Loop="TTCG",spacer=" ",Tail="TTTCTGCGTTTA",Forward_Efficiency="88+2%",Reverse_Efficiency="",Full_sequnce="CTGGCTCACCTTCGGGTGGGCCTTTCTGCGTTTA",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="T3Te",Category="wild type",Direction="Forward",Environment="phage terminator",Stem_Loop_Sequence="GGCTCACCTTCACGGGTGAGCC",Loop="TTCACG",spacer=" ",Tail="TTTCTTCGTTC",Forward_Efficiency="14+2%",Reverse_Efficiency="",Full_sequnce="GGCTCACCTTCACGGGTGAGCCTTTCTTCGTTC",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="tR2",Category="wild type",Direction="Forward",Environment="phage terminator",Stem_Loop_Sequence="GGCCTGCTGGTAATCGCAGGCC",Loop="TGGTAATC",spacer=" ",Tail="TTTTTAATTTGGG",Forward_Efficiency="49+4%",Reverse_Efficiency="",Full_sequnce="GGCCTGCTGGTAATCGCAGGCCTTTTTATTTGGG",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="RNA I",Category="wild type",Direction="Forward",Environment="phage terminator",Stem_Loop_Sequence="ACCACCGTTGGTTAGCGGTGG",Loop="GGT",spacer=" ",Tail="TTTTTTGTTTG",Forward_Efficiency="73+4%",Reverse_Efficiency="",Full_sequnce="AAACCACCGTTGGTTAGCGGTGGTTTTTTGTTTG",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="ampL35A mutant",Category="wild type",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CGGCCCGCCUAUGGCGGGCC",Loop="TAT",spacer=" ",Tail="TTTT",Forward_Efficiency="<1%",Reverse_Efficiency="",Full_sequnce="AUCGCCAAUGUAAAUCCGGCCCGCCUAUGGCGGGCCGUUUU",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="tR2-6",Category="mutant",Direction="Forward",Environment="phage terminator mutant",Stem_Loop_Sequence="AGGGGACGTGGTAATCCGTCCCC",Loop="TGGTAATC",spacer=" ",Tail="TTTTTATT",Forward_Efficiency="56%",Reverse_Efficiency="",Full_sequnce="GTTAATAACAGGGGACGTGGTAATCCGTCCCCTTTTTATT",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="tR2-11",Category="mutant",Direction="Forward",Environment="phage terminator mutant",Stem_Loop_Sequence="AGGCCTGGCTGGTAATCGCCAGGCCT",Loop="TGGTAATC",spacer=" ",Tail="TTTTATT",Forward_Efficiency="54%",Reverse_Efficiency="",Full_sequnce="TAATAACAGGCCTGGCTGGTAATCGCCAGGCCTTTTTATT",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="tR2-12",Category="mutant",Direction="Forward",Environment="phage terminator mutant",Stem_Loop_Sequence="AGGCCTGCTTCGGCAGGCCT",Loop="TTCG",spacer=" ",Tail="TTTTATT",Forward_Efficiency="69%",Reverse_Efficiency="",Full_sequnce="CCGGGTTAATAACAGGCCTGCTTCGGCAGGCCTTTTTATT",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="tR2-13",Category="mutant",Direction="Forward",Environment="phage terminator mutant",Stem_Loop_Sequence="GGCCTCTGGTAATCGAGGC",Loop="TGGTAATC",spacer=" ",Tail="TTTTTATT",Forward_Efficiency="11%",Reverse_Efficiency="",Full_sequnce="CGGGTTATTAACAGGCCTCTGGTAATCGAGGCTTTTTATT",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="tR2-14",Category="mutant",Direction="Forward",Environment="phage terminator mutant",Stem_Loop_Sequence="GGGGACGTGGTAATCGCCAGCAGGCC",Loop="TGGTAATC",spacer=" ",Tail="TTTTTATT",Forward_Efficiency="20%",Reverse_Efficiency="",Full_sequnce="ATAACAGGGGACGTGGTAATCGCCAGCAGGCCTTTTTATT",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="tR2-16",Category="mutant",Direction="Forward",Environment="phage terminator mutant",Stem_Loop_Sequence="GGCCTGCTGGTAATCGCAGGCC",Loop="TGGTAATC",spacer=" ",Tail="TTTTTATT",Forward_Efficiency="36%",Reverse_Efficiency="",Full_sequnce="GTTAATAAAAGGCCTGCTGGTAATCGCAGGCCTTTTTATT",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="tR2-17",Category="mutant",Direction="Forward",Environment="phage terminator mutant",Stem_Loop_Sequence="GGCCTGCTGGTAATCGCAGGCC",Loop="TGGTAATC",spacer=" ",Tail="TTTTTATT",Forward_Efficiency="67%",Reverse_Efficiency="",Full_sequnce="GGTTCTTCTCGGCCTGCTGGTAATCGCAGGCCTTTTTATT",Reference="Balanced branching in transcription termination K. J. Harrington, R. B. Laughlin, and S. Liang",Note=""},

                new Terminator1(){Terminator_Name="trpA L153",Category="wild type",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCGCCTAATGAGCGG",Loop="CTAATGA",spacer=" ",Tail="TTTTTTTTGAACTGCA",Forward_Efficiency="24%",Reverse_Efficiency="",Full_sequnce="AGCTTAGCAATCAGATACCCAGCCCGCCTAATGAGCGGACTTTTTTTTGAACTGCA",Reference="Takahiko Nojima,Angela C.Lin,Teruo Fujii,&Isao Endo,(2005)Japan Society for Analytical Chemistry,VOL.21,1479-1481.",Note=""},

                new Terminator1(){Terminator_Name="λtR2",Category="wild type",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCCTGCTGGTAATCGCAGGCC",Loop="TGGTAATC",spacer=" ",Tail="TTTTTATTTCTGCA",Forward_Efficiency="79%",Reverse_Efficiency="",Full_sequnce="TACTGAGCTAATAACAGGCCTGCTGGTAATCGCAGGCCTTTTTATTTCTGCA",Reference="Takahiko Nojima,Angela C.Lin,Teruo Fujii,&Isao Endo,(2005)Japan Society for Analytical Chemistry,VOL.21,1479-1482.",Note=""},

                new Terminator1(){Terminator_Name="rrmB T1",Category="wild type",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCTCAGTCGAAAGACTGGGCC",Loop="GAAA",spacer=" ",Tail="TTTCGTTTTAATCT",Forward_Efficiency="89%",Reverse_Efficiency="",Full_sequnce="AGCTTTCAAATAAAACGAAAGGCTCAGTCGAAAGACTGGGCCTTTCGTTTTAATCT",Reference="Takahiko Nojima,Angela C.Lin,Teruo Fujii,&Isao Endo,(2005)Japan Society for Analytical Chemistry,VOL.21,1479-1483.",Note=""},

                new Terminator1(){Terminator_Name="rnpB_T1",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCGCTTCGGCGGG",Loop="TTCG",spacer=" ",Tail="TTTTTGCTTTTGGAGGGGCAGAAAGATGAATGACTGTC",Forward_Efficiency="99%",Reverse_Efficiency="",Full_sequnce="TCGGTCAGTTTCACCTGATTTACGTAAAAACCCGCTTCGGCGGGTTTTTGCTTTTGGAGGGGCAGAAAGATGAATGACTGTC",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="ilvGEDA_T",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCCCGCACCGAAAGGTCCGGGGG",Loop="GAAA",spacer=" ",Tail="TTTTTTTTGACCTTAAAAACATAACCGAGGAGCAGACA",Forward_Efficiency="99%",Reverse_Efficiency="",Full_sequnce="TAGAGATCAAGCCTTAACGAACTAAGACCCCCGCACCGAAAGGTCCGGGGGTTTTTTTTGACCTTAAAAACATAACCGAGGAGCAGACA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="rrnD_T1",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CAAAAGGCTCAGTCGGAAGACTGGGCCTTTTG",Loop="GGAA",spacer=" ",Tail="TTTTATCTGTTGTTTGTCGGTGAACACTCTCCCG",Forward_Efficiency="98%",Reverse_Efficiency="",Full_sequnce="GGGAACTGCCAGACATCAAATAAAACAAAAGGCTCAGTCGGAAGACTGGGCCTTTTGTTTTATCTGTTGTTTGTCGGTGAACACTCTCCCG",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="BBa_B1006_T",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCCGCCCCTGACAGGGCGGGG",Loop="CTGACA",spacer=" ",Tail="TTTTTTTT",Forward_Efficiency="98%",Reverse_Efficiency="",Full_sequnce="AAAAAAAAACCCCGCCCCTGACAGGGCGGGGTTTTTTTT",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="rrnB_T1",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CGAAAGGCTCAGTCGAAAGACTGGGCCTTTCG",Loop="GAAA",spacer=" ",Tail="TTTTATCTGTTGTTTGTCGGTGAACGCTCTCCTG",Forward_Efficiency="97%",Reverse_Efficiency="",Full_sequnce="GGGAACTGCCAGGCATCAAATAAAACGAAAGGCTCAGTCGAAAGACTGGGCCTTTCGTTTTATCTGTTGTTTGTCGGTGAACGCTCTCCTG",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="M13_central_T",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCTCCTTTTGGAGCC",Loop="TTTT",spacer=" ",Tail="TTTTTTTTTGGAGATTTTCAACATGAAAAAATTATTATT",Forward_Efficiency="96%",Reverse_Efficiency="",Full_sequnce="AAAGCAAGCTGATAAACCGATACAATTAAAGGCTCCTTTTGGAGCCTTTTTTTTTGGAGATTTTCAACATGAAAAAATTATTATT",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="trp_att_L126",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GCCCGCCTAATAAGCGGGC",Loop="CTAATAA",spacer=" ",Tail="TTTTTTTTGAACAAAATTAGAGAATAACAATGCAAACA",Forward_Efficiency="96%",Reverse_Efficiency="",Full_sequnce="TTCACCATGCGTAAAGCAATCAGATACCCAGCCCGCCTAATAAGCGGGCTTTTTTTTGAACAAAATTAGAGAATAACAATGCAAACA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="T7_Te",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCTCACCTTCGGGTGGGCC",Loop="TTCG",spacer=" ",Tail="TTTCTGCGTTTATAAGGAGACACTTTATGTTTAAGAAG",Forward_Efficiency="95%",Reverse_Efficiency="",Full_sequnce="ACAACCCTCAAGAGAAAATGTAATCACACTGGCTCACCTTCGGGTGGGCCTTTCTGCGTTTATAAGGAGACACTTTATGTTTAAGAAG",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="T3_Te",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCTCACCTTCACGGGTGGGCC",Loop="TCAC",spacer=" ",Tail="TTTCTTCGTTCCGGGCATTAACCCTCACTAACAGGAGA",Forward_Efficiency="94%",Reverse_Efficiency="",Full_sequnce="ACCCTCAAGAGAAAATGTAACCAACTCACTGGCTCACCTTCACGGGTGGGCCTTTCTTCGTTCCGGGCATTAACCCTCACTAACAGGAGA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="trp_att_L126_L",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GCCCGCCTAAAGCGGGC",Loop="CTAAA",spacer=" ",Tail="TTTTTTTTGAACAAAATTAGAGAATAACAATGCAAACA",Forward_Efficiency="94%",Reverse_Efficiency="",Full_sequnce="TTCACCATGCGTAAAGCAATCAGATACCCAGCCCGCCTAAAGCGGGCTTTTTTTTGAACAAAATTAGAGAATAACAATGCAAACA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="RNA_I_T",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCACCGTTGGTAGCGGTGG",Loop="TGGTA",spacer=" ",Tail="TTTTTTTGTTTGCAAGCAGCAGATTACGCGCAGAAAAAAAGG",Forward_Efficiency="92%",Reverse_Efficiency="",Full_sequnce="GAGTTGGTAGCTCTTGATCCGGCAAACAAACCACCGTTGGTAGCGGTGGTTTTTTTGTTTGCAAGCAGCAGATTACGCGCAGAAAAAAAGG",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="lambda_tR2",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCCTGCTGGTAATCGCAGGCC",Loop="TGGTAATC",spacer=" ",Tail="TTTTTATTTGGGGGAGAGGGAAGTCATGAAAAAACTAAC",Forward_Efficiency="90%",Reverse_Efficiency="",Full_sequnce="ATGACCATCTACATTACTGAGCTAATAACAGGCCTGCTGGTAATCGCAGGCCTTTTTATTTGGGGGAGAGGGAAGTCATGAAAAAACTAAC",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="spacer80GC0.5",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CTCCCGATCTTAATGAATGGCCGGAAG",Loop="ATGAA",spacer=" GA",Tail="TGGT",Forward_Efficiency="85%",Reverse_Efficiency="",Full_sequnce="TAAATCCGCGCGATAGGGCATTAGAGGTTTAATTTTGTATGGCAAGGTACTCCCGATCTTAATGAATGGCCGGAAGTGGT",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="T21_T",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GCTGCCGTTAGTGACTCTTAAGTTGCAACGGTGGC",Loop="ACTTA",spacer=" ",Tail="TTTTTTTATTTGGGTCAGTCGTATAAAGGTCATTACGGA",Forward_Efficiency="79%",Reverse_Efficiency="",Full_sequnce="ATTGAGCAAGTAGCAACACTATTCGCATAAGCTGCCGTTAGTGACTCTTAAGTTGCAACGGTGGCTTTTTTTATTTGGGTCAGTCGTATAAAGGTCATTACGGA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="tonB_T",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GCCTCCGACCGGAGGC",Loop="GACC",spacer=" ",Tail="TTTTGACTATTACTCAACAGGTAAGGCGCGAGGTTTTC",Forward_Efficiency="77%",Reverse_Efficiency="",Full_sequnce="CACCGAAATTCAGTAAGCAGAAAGTCAAAAGCCTCCGACCGGAGGCTTTTGACTATTACTCAACAGGTAAGGCGCGAGGTTTTC",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="lambda_tR2_1",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCCTGCTGGTAATCGCAGACC",Loop="CTGGTAATCA",spacer=" ",Tail="TTTTTATTTGGGGGAGAGGGAAGTCATGAAAAAACTAAC",Forward_Efficiency="67%",Reverse_Efficiency="",Full_sequnce="ATGACCATCTACATTACTGAGCTAATAACAGGCCTGCTGGTAATCGCAGACCTTTTTATTTGGGGGAGAGGGAAGTCATGAAAAAACTAAC",Reference="http://io.biofab.org/services/studio/dac/",Note=""},


                new Terminator1(){Terminator_Name="crp_T",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCGCGTTACCTGGTAGCGCGCC",Loop="CTG",spacer=" A",Tail="TTTTGTTTCCCCCGATGTGGCGCAGACTGATTTATCAC",Forward_Efficiency="66%",Reverse_Efficiency="",Full_sequnce="CGTTTACGGCACTCGTTAATCCCGTCGGAGTGGCGCGTTACCTGGTAGCGCGCCATTTTGTTTCCCCCGATGTGGCGCAGACTGATTTATCAC",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="his_T_var",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GCCCCCGGAAGATGCATCTTCCGGGGGC",Loop="TGCA",spacer=" ",Tail="TTTTTTTTTGCGCGGTTGATAACGGTTCAGACAGGTTTA",Forward_Efficiency="53%",Reverse_Efficiency="",Full_sequnce="TCTTCCAGTGGTGCATGAACGCATGAGAAAGCCCCCGGAAGATGCATCTTCCGGGGGCTTTTTTTTTGCGCGGTTGATAACGGTTCAGACAGGTTTA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="amyA_T_L",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CACCTCCAAGCTGAGTGCGGTCAGCTTGGAGGTG",Loop="GTGCGG",spacer=" ",Tail="TTTATTTTTTCAGCCGTATGACAAGGTCGGCATCAGGTGT",Forward_Efficiency="53%",Reverse_Efficiency="",Full_sequnce="TTTATGTTCAGAAATAAGGTAATAAAAAAACACCTCCAAGCTGAGTGCGGTCAGCTTGGAGGTGCGTTTATTTTTTCAGCCGTATGACAAGGTCGGCATCAGGTGT",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="his_T",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GCCCCCGGAAGATCACCTTCCGGGGGC",Loop="ATCAC",spacer=" ",Tail="TTTTTTATTGCGCGGTTGATAACGGTTCAGACAGGTTTA",Forward_Efficiency="52%",Reverse_Efficiency="",Full_sequnce="TCTTCCAGTGGTGCATGAACGCATGAGAAAGCCCCCGGAAGATCACCTTCCGGGGGCTTTTTTATTGCGCGGTTGATAACGGTTCAGACAGGTTTA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="trp_att_1419",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GCCCGCCTAATGAGCGGGC",Loop="CTAATGA",spacer=" ",Tail="TTTTGAACAAAATTAGAGAATAACAATGCAAACA",Forward_Efficiency="50%",Reverse_Efficiency="",Full_sequnce="TTCACCATGCGTAAAGCAATCAGATACCCAGCCCGCCTAATGAGCGGGCTTTTGAACAAAATTAGAGAATAACAATGCAAACA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="amyA_T",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CACCTCCAAGCTGAGTGCGGGTATCAGCTTGGAGGTG",Loop="GTGCGGGTA",spacer=" CG",Tail="TTTATTTTTTCAGCCGTATGACAAGGTCGGCATCAGGTGT",Forward_Efficiency="49%",Reverse_Efficiency="",Full_sequnce="TTTATGTTCAGAAATAAGGTAATAAAAAAACACCTCCAAGCTGAGTGCGGGTATCAGCTTGGAGGTGCGTTTATTTTTTCAGCCGTATGACAAGGTCGGCATCAGGTGT",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="amyA_T_L2",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CACCTCCAAGCTGAGTGCGGGTACAGCTTGGAGGTG",Loop="AGTGCGGGTA",spacer=" CG",Tail="TTTATTTTTTCAGCCGTATGACAAGGTCGGCATCAGGTGT",Forward_Efficiency="49%",Reverse_Efficiency="",Full_sequnce="TTTATGTTCAGAAATAAGGTAATAAAAAAACACCTCCAAGCTGAGTGCGGGTACAGCTTGGAGGTGCGTTTATTTTTTCAGCCGTATGACAAGGTCGGCATCAGGTGT",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="tn10_tetA/tetC_T",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCTCTTGATAACCCAAGAGGG",Loop="ATAACC",spacer="CA ",Tail="TTTTTTACGATAAAGAAGATTTAGCTTCAAATAAAAC",Forward_Efficiency="46%",Reverse_Efficiency="",Full_sequnce="TATTTCGTCACCAAATGATGTTATTCCGCGAAATATAATGACCCTCTTGATAACCCAAGAGGGCATTTTTTACGATAAAGAAGATTTAGCTTCAAATAAAAC",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="his_T_var_L",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GCCCCCGGAAGATGCAGGGGC",Loop="CGGAAGATGCA",spacer=" ",Tail="TTTTTTTTTGCGCGGTTGATAACGGTTCAGACAGGTTTA",Forward_Efficiency="46%",Reverse_Efficiency="",Full_sequnce="TCTTCCAGTGGTGCCATGAACGCATGAGAAAGCCCCCGGAAGATGCAGGGGCTTTTTTTTTGCGCGGTTGATAACGGTTCAGACAGGTTTA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="amyA_T_S",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CACCTCCAAGCTGAGTGCGGGTATTTGGAGGTG",Loop="GAGTGCG",spacer=" CG",Tail="TTTATTTTTTCAGCCGTATGACAAGGTCGGCATCAGGTGT",Forward_Efficiency="36%",Reverse_Efficiency="",Full_sequnce="TTTATGTTCAGAAATAAGGTAATAAAAAAACACCTCCAAGCTGAGTGCGGGTATTTGGAGGTGCGTTTATTTTTTCAGCCGTATGACAAGGTCGGCATCAGGTGT",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="spacer40GC0.32",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GTGTCTATTATCCCTAAGCCC",Loop="TTATCCC",spacer="A ",Tail="TTTTTTGCA",Forward_Efficiency="32%",Reverse_Efficiency="",Full_sequnce="ATTTGTAAAGTGTCTATTATCCCTAAGCCCATTTTTTGCA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="lambda_tR2_L",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCCTGCCGCAGGCC",Loop="CCG",spacer=" ",Tail="TTTTTATTTGGGGGAGAGGGAAGTCATGAAAAAACTAAC",Forward_Efficiency="31%",Reverse_Efficiency="",Full_sequnce="TGACCATCTACATTACTGAGCTAATAACAGGCCTGCCGCAGGCCTTTTTATTTGGGGGAGAGGGAAGTCATGAAAAAACTAAC",Reference="http://io.biofab.org/services/studio/dac/",Note=""},


                new Terminator1(){Terminator_Name="BBa_B1002_T_Lvar",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="CCCCGCTGCGGGG",Loop="CTG",spacer=" ",Tail="TTTTTTCGC",Forward_Efficiency="25%",Reverse_Efficiency="",Full_sequnce="CGCAAAAAACCCCGCTGCGGGGTTTTTTCGC",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="attCaadA7",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GCCGACGCCGCTTCGCGGCGCGGC",Loop="TTC",spacer=" ",Tail="TTAATTCAAGCGTTAGATGCACTAAGCACATAATTGCTCACAGCCAA",Forward_Efficiency="24%",Reverse_Efficiency="",Full_sequnce="TGATAGTAAACTGCTTGGTGCCAGCCAATGATGTCTAACAATTCATTCAAGCCGACGCCGCTTCGCGGCGCGGCTTAATTCAAGCGTTAGATGCACTAAGCACATAATTGCTCACAGCCAA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},

                new Terminator1(){Terminator_Name="spacer80GC0.3",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="TCGATACATAAAATATTTCGA",Loop="AAA",spacer=" ",Tail="TTGCATGTGCAATTTGTAAAGTGTCTATTATCCCTAAGCCCATTTTTTGCA",Forward_Efficiency="21%",Reverse_Efficiency="",Full_sequnce="ATATTATATCGATACATAAAATATTTCGATTGCATGTGCAATTTGTAAAGTGTCTATTATCCCTAAGCCCATTTTTTGCA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},



                new Terminator1(){Terminator_Name="BBa_B1002_T_LSvar",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GCAAAAAACCCCGC",Loop="AAAAAACCCC",spacer=" ",Tail="TGGGGTTTTTTCGC",Forward_Efficiency="21%",Reverse_Efficiency="",Full_sequnce="TGATCGCAAAAAACCCCGCTGGGGTTTTTTCGC",Reference="http://io.biofab.org/services/studio/dac/",Note=""},



                new Terminator1(){Terminator_Name="spacer50GC0.23",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="TCGATACATAAAATATTTCGA",Loop="AAA",spacer=" ",Tail="TTGCATGTGCAATTTTTTGCA",Forward_Efficiency="6%",Reverse_Efficiency="",Full_sequnce="ATATTATATCGATACATAAAATATTTCGATTGCATGTGCAATTTTTTGCA",Reference="http://io.biofab.org/services/studio/dac/",Note=""},


 new Terminator1(){Terminator_Name="REF lambda_tR2_S",Category="unknown",Direction="Forward",Environment="E. coli",Stem_Loop_Sequence="GGCCTGCTGGTAATGGCC",Loop="TGCTGGTAAT",spacer=" ",Tail="TTTTTATTTGGGGGAGAGGGAAGTCATGAAAAAACTAAC",Forward_Efficiency="0%",Reverse_Efficiency="",Full_sequnce="TGACCATCTACATTACTGAGCTAATAACAGGCCTGCTGGTAATGGCCTTTTTATTTGGGGGAGAGGGAAGTCATGAAAAAACTAAC",Reference="http://io.biofab.org/services/studio/dac/",Note=""}



            };

            this.terminatorlist.ItemsSource = terList;
        }
    }
}